import Head from 'next/head'
export default function Impressum(){ 
  return (
    <>
      <Head><title>Impressum</title></Head>
      <div style={{padding:'40px',fontFamily:'Inter, Arial'}}>
        <h1>Impressum</h1>
        <p>This site is maintained by Vignesh Anandapadmanabhan. Please update this page with your business address and contact details to comply with local laws.</p>
      </div>
    </>
  )
}

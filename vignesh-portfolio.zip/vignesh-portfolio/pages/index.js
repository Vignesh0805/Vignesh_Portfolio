import Head from 'next/head'

export default function Home() {
  const mail = "mahendran05394@gmail.com";
  const name = "Vignesh Anandapadmanabhan";
  const title = "E-Commerce & Digital Business Head";

  function handleContact(e) {
    e.preventDefault();
    const form = e.target;
    const subject = encodeURIComponent('Portfolio contact from ' + form.name.value);
    const body = encodeURIComponent(`Name: ${form.name.value}\nEmail: ${form.email.value}\n\nMessage:\n${form.message.value}`);
    window.location.href = `mailto:${mail}?subject=${subject}&body=${body}`;
  }

  return (
    <>
      <Head>
        <title>{name} — {title}</title>
        <meta name="description" content="Portfolio of Vignesh Anandapadmanabhan — E-Commerce & Digital Business Head. Open to roles in Germany, UAE & Australia." />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet" />
      </Head>

      <header className="site-header">
        <div className="container header-grid">
          <a className="brand" href="#home">{name.split(' ')[0]}</a>
          <nav className="nav">
            <a href="#about">About</a>
            <a href="#experience">Experience</a>
            <a href="#projects">Projects</a>
            <a href="#contact" className="btn primary">Contact</a>
          </nav>
        </div>
      </header>

      <main id="home">
        <section className="hero">
          <div className="container hero-grid">
            <div className="hero-left">
              <p className="kicker">E-Commerce & Digital Business Head</p>
              <h1 className="hero-title">{name}</h1>
              <p className="hero-sub">Driving measurable e-commerce growth across omnichannel retail and digital marketing. Open to roles in Germany, UAE & Australia.</p>
              <div className="actions">
                <a href="#projects" className="btn outline">View Projects</a>
                <a href="/cv/Vignesh_CV_EN.pdf" className="btn primary" download>Download CV</a>
              </div>

              <ul className="chips">
                <li>HP</li><li>Samsung</li><li>Open to Relocate</li>
              </ul>
            </div>

            <aside className="profile-card">
              <img src="/profile.svg" alt="Profile photo placeholder" className="profile-photo" />
              <div className="kv"><strong>Location</strong><span>India (Open to relocate)</span></div>
              <div className="kv"><strong>Languages</strong><span>English, Tamil</span></div>
              <div className="kv"><strong>Contact</strong><span><a href="mailto:mahendran05394@gmail.com">mahendran05394@gmail.com</a></span></div>
            </aside>
          </div>
        </section>

        <section id="about" className="section about">
          <div className="container">
            <h2>About</h2>
            <p>I’m a business & e-commerce manager with experience leading digital growth initiatives for global tech brands such as HP and Samsung. I combine data-driven digital marketing, product merchandising, and omnichannel retail strategy to deliver measurable business outcomes — from conversion lifts to AOV improvements.</p>
            <p>I lead cross-functional teams, manage product portfolios, and translate analytics into actionable commercial decisions. My focus is practical: improve availability, optimize funnels, and scale profitable campaigns.</p>

            <div className="skills">
              <div className="skill">E-commerce Strategy</div>
              <div className="skill">Digital Marketing & Analytics</div>
              <div className="skill">Cross-functional Leadership</div>
            </div>
          </div>
        </section>

        <section id="experience" className="section">
          <div className="container">
            <h2>Experience</h2>
            <div className="cards">
              <article className="card">
                <h3>HP — E-commerce Business Manager</h3>
                <p className="meta">Jan 2022 — Present</p>
                <ul>
                  <li>Managed desktop & accessories vertical; optimized product availability and promotions.</li>
                  <li>Improved category conversion by <strong>18%</strong> via product feed & page optimizations.</li>
                  <li>Collaborated on stock-transit dashboards and cross-channel promotions.</li>
                </ul>
              </article>

              <article className="card">
                <h3>Samsung Exclusive Showroom — E-commerce Lead</h3>
                <p className="meta">Jun 2019 — Dec 2021</p>
                <ul>
                  <li>Managed showroom operations and led e-commerce rollouts for retail.</li>
                  <li>Integrated offline campaigns with online funnels; increased showroom-attributed online sales by <strong>26%</strong>.</li>
                  <li>Implemented weekly stock sync and localized campaigns.</li>
                </ul>
              </article>

              <article className="card">
                <h3>Aanvii Hearing Solutions — Cluster Manager</h3>
                <p className="meta">2016 — 2019</p>
                <ul>
                  <li>Managed business across Andhra Pradesh, Telangana, Tamil Nadu & Kerala.</li>
                  <li>Improved regional inventory distribution and local marketing performance.</li>
                </ul>
              </article>
            </div>
          </div>
        </section>

        <section id="projects" className="section projects">
          <div className="container">
            <h2>Projects & Case Studies</h2>

            <div className="case">
              <div className="case-text">
                <h3>HP — Category Conversion Lift</h3>
                <p><strong>Challenge:</strong> Low conversion for new SKUs and inconsistent product pages.</p>
                <p><strong>Action:</strong> Redesigned page templates, improved product feed, ran A/B tests and remarketing.</p>
                <p><strong>Result:</strong> Conversion improved by <strong>+18%</strong>, AOV +8%, CPC -12%.</p>
              </div>
              <div className="case-img"><img src="/project1.svg" alt="Project 1 mock" /></div>
            </div>

            <div className="case">
              <div className="case-text">
                <h3>Samsung — Omnichannel Launch</h3>
                <p><strong>Challenge:</strong> Showroom activity not translating to online sales.</p>
                <p><strong>Action:</strong> Synchronized SKUs, ran geo-targeted campaigns, introduced QR-driven product pages.</p>
                <p><strong>Result:</strong> Online sales from showroom campaigns +<strong>26%</strong>; leads doubled.</p>
              </div>
              <div className="case-img"><img src="/project2.svg" alt="Project 2 mock" /></div>
            </div>

            <div className="case">
              <div className="case-text">
                <h3>Campaign Efficiency — Performance Marketing</h3>
                <p><strong>Challenge:</strong> High CAC and low ROAS across campaigns.</p>
                <p><strong>Action:</strong> Audience segmentation, GA4 event tracking, creative optimization.</p>
                <p><strong>Result:</strong> CAC reduced, CTR improved, ROAS increased to target levels.</p>
              </div>
              <div className="case-img"><img src="/project3.svg" alt="Project 3 mock" /></div>
            </div>

          </div>
        </section>

        <section className="section certs">
          <div className="container">
            <h2>Certifications & Skills</h2>
            <div className="cert-grid">
              <div className="cert">HubSpot — Inbound</div>
              <div className="cert">Google Analytics (GA4)</div>
              <div className="cert">Meta Ads</div>
              <div className="cert">LinkedIn Learning</div>
            </div>

            <div className="skill-pills">
              <span>GA4</span><span>Power BI</span><span>Excel (Advanced)</span><span>Shopify</span><span>SEM</span><span>Meta Ads</span>
            </div>
          </div>
        </section>

        <section id="contact" className="section contact">
          <div className="container">
            <h2>Contact</h2>
            <p>Interested in discussing e-commerce growth or digital strategy roles? Email me or use the contact form below.</p>

            <div className="contact-grid">
              <form onSubmit={handleContact} className="contact-form">
                <label>Name<input name="name" required /></label>
                <label>Email<input name="email" type="email" required /></label>
                <label>Message<textarea name="message" required /></label>
                <button className="btn primary" type="submit">Send</button>
              </form>

              <div className="contact-card">
                <h3>Get in touch</h3>
                <p><strong>Email:</strong> <a href="mailto:mahendran05394@gmail.com">mahendran05394@gmail.com</a></p>
                <p><strong>LinkedIn:</strong> <a href="https://www.linkedin.com" target="_blank" rel="noreferrer">View profile</a></p>
              </div>
            </div>

          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="container footer-grid">
          <div>© 2025 Vignesh — All rights reserved.</div>
          <div><a href="/impressum">Impressum</a> | <a href="/privacy">Privacy</a></div>
        </div>
      </footer>

    </>
  )
}

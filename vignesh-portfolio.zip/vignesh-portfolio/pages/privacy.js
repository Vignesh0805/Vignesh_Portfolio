import Head from 'next/head'
export default function Privacy(){ 
  return (
    <>
      <Head><title>Privacy</title></Head>
      <div style={{padding:'40px',fontFamily:'Inter, Arial'}}>
        <h1>Privacy Policy</h1>
        <p>This is a placeholder privacy policy. Update with GDPR-compliant text before publishing for EU targeting.</p>
      </div>
    </>
  )
}
